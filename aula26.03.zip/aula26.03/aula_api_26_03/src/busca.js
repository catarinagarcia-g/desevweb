

export function buscar() {
    document.getElementById("btn").addEventListener("click", ()=>{

        // alert("clicou")


    fetchSpells();

    })
}


async function fetchSpells() {
    const res = await fetch('https://potterapi-fedeperin.vercel.app/en/spells')
    const spells = await res.json()
    
    console.log(spells);
}