import './style.css'
import javascriptLogo from './javascript.svg'
import viteLogo from '/vite.svg'
import { setupCounter } from './counter.js'
import { buscar } from './busca.js'



document.querySelector('#app').innerHTML = /*html*/`
<div>
<h1>titulo da pagina</h1>
<input type= "text">
<button id="btn"> Buscar </button>
</div>
`

// setupCounter(document.querySelector('#counter'))
buscar();
